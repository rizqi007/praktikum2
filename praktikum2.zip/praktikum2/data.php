<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css "href="css/bootstrap.min.css">
</head>
<body>
    

<div class="container">
    <div class="row">
        <div class="col-12">
            <h2 class="text-center">Tambah Nilai</h2>
        </div>
        <div class="col-3"></div>
        <div class="col-6">
            <form action="index.php" method="POST" enctype="multipart/form-data">
                <div class="mb-2">
                    <label class="form-label">NIM</label>
                    <input type="number" name="nim" class="form-control" placeholder="Masukkan Nim">
                </div>
                <div class="mb-2">
                    <label class="form-label">Nama</label>
                    <input type="text" name="nama" class="form-control" placeholder="Masukkan Nama">
                </div>
                <div class="mb-2">
                    <label class="form-label">Mata Kuliah</label>
                    <select name="matkul" class="form-select">
                        <option value="WEB">WEB</option>
                        <option value="Bahasa Inggris">Bahasa Inggris</option>
                        <option value="PKN">PKN</option>
                        <option value="Jarkom">Jaringan Komputer</option>
                        <option value="Basdat">Basis Data</option>
                        <option value="UIUX">User interface&Experience</option>
                        <option value="KK">Keterampilan Komunikasi</option>
                        <option value="SP">Statistik dan Probabilitas</option>
                    </select>
                </div>
                <div class="mb-2">
                    <label class="form-label">Nilai UTS</label>
                    <input type="number" name="uts" class="form-control" placeholder="Masukkan Nilai UTS">
                </div>
                <div class="mb-2">
                    <label class="form-label">Nilai UAS</label>
                    <input type="number" name="uas" class="form-control" placeholder="Masukkan Nilai UAS">
                </div>
                <div class="mb-2">
                    <label class="form-label">Nilai Tugas</label>
                    <input type="number" name="nilai_tugas" class="form-control" placeholder="Masukkan Nilai Tugas">
                </div>
                <button type="submit" class="btn btn-primary">Submit</button>
                <a href="index.php" class="btn btn-danger">Back</a>
            </form>
        </div>
    </div>
</div>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
</body>
</html>